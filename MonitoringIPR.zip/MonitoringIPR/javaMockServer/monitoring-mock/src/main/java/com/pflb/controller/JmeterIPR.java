package com.pflb.controller;

import com.pflb.entity.JmeterIPREntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
public class JmeterIPR {

    @PostMapping("/return/sum")
    public ResponseEntity<String> getResponse(HttpServletRequest request, @RequestBody JmeterIPREntity body) throws InterruptedException {
        Thread.sleep((int) (Math.random() * 500));
        long time = System.currentTimeMillis();
        if (time%10==0) {
            return ResponseEntity.status(500)
                    .header("Content-Type", "application/json")
                    .body("{\n" +
                            "   \"Server custom error\": \"true\"\n" +
                            "}");
        }
        try {
            return ResponseEntity.ok()
                    .header("Content-Type", "application/json")
                    .body("{\n" +
                    "    \"sum\": \"" + this.getSum(body.getFirstValue(), body.getSecondValue()) + "\",\n" +
                    "}");
        } catch (Exception exception) {
            request.setAttribute("status", "Status: Bad request: " + exception.getMessage());
            exception.printStackTrace();
            return ResponseEntity.badRequest().body(exception.getMessage());
        }
    }


    private int getSum(String firstValue, String secondValue){
        return Integer.parseInt(firstValue) + Integer.parseInt(secondValue);
    }
}
