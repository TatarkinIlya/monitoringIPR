Для выолнения задания использовалься один POST запрос с 2 рандомными цислами. Кастомная заглушка возвращает сумму этих числел с ранндомной задержкой 0-500ms.
Для наглядности в заглушке реализована ошибка с кодом ответа 500 при условии, если UNIX timestamp в момент запроса делится на 10 без остатка. Процент ошибок должен быть равен ~ 10%


Ссылка на дешборд графаны + инструкиция для jmeter.
https://grafana.com/grafana/dashboards/13644/revisions

Подружить grafana + influx 2+ (Query Language = Flux)
https://docs.influxdata.com/influxdb/v2.1/tools/grafana/#configure-grafana-to-use-flux